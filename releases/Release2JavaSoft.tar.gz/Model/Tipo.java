package Model;

public enum Tipo {
    TERRESTRE, AQUATICO, AEREO, ANFIBIO;
}
