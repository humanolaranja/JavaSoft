import java.time.LocalDate;
import java.util.ArrayList;

public class Pesquisador extends Funcionario{
	
	// Vari�veis final
	public static final int GRADUACAO = 1;
	public static final int POS_GRADUACAO = 2;
	public static final int PROFESSOR = 3;
	
	// Atributos
	private int tipo;
	private ArrayList<Animal> animaisPesquisa;
	
	// Construtor
	public Pesquisador(String nome, String rg, LocalDate nascimento, int turno, String numCarteiraTrabalho, double salario, LocalDate dataContratacao, int tipo, ArrayList<Animal> animaisPesquisa) {
		super(nome, rg, nascimento, turno, numCarteiraTrabalho, salario, dataContratacao);
		this.animaisPesquisa = new ArrayList<>();
		this.animaisPesquisa = animaisPesquisa;
	}

	public int getTipo() {
		return this.tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public ArrayList<Animal> getAnimaisPesquisa() {
		return this.animaisPesquisa;
	}

	public void setAnimaisPesquisa(ArrayList<Animal> animaisPesquisa) {
		this.animaisPesquisa = animaisPesquisa;
	}
	
	// Adiciona um animal � lista
	public void adicionarAnimal(Animal a) {
		getAnimaisPesquisa().add(a);
	}
	
	// Remove um animal da posi��o i
	public void removerAnimal(int i) {
		getAnimaisPesquisa().remove(i);
	}
	
	// Imprime os dados
	@Override
	public void imprimirDados() {
		System.out.println("-Nome: " + this.getNome());
		System.out.println("-RG: " + this.getRg());
		System.out.println("-Data de nascimento: " + this.getDataNascimento().toString());
		System.out.println("-Data de contrata��o: " + this.getDataContratacao().toString());
		System.out.println("-Sal�rio: " + this.getSalario());
		System.out.println("-Carteira de trabalho: " + this.getNumCarteiraTrabalho());
		System.out.print("-Turno: ");
            switch (this.getTurno()) {
                case TURNO_MANHA:
                    System.out.println("manh�\n");
                    break;
                case TURNO_TARDE:
                    System.out.println("tarde");
                    break;
                default:
                    System.out.println("noite");
                    break;
            }
		System.out.print("-Tipo: ");
            switch (this.getTipo()) {
                case GRADUACAO:
                    System.out.println("gradua��o");
                    break;
                case POS_GRADUACAO:
                    System.out.println("p�s-gradu��o");
                    break;
                default:
                    System.out.println("professor");
                    break;
            }
	}
}
