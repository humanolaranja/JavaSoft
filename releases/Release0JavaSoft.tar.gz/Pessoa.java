import java.time.LocalDate;

public class Pessoa {
	
	// Atributos
	private final String nome;
	private final String rg;
	private final LocalDate dataNascimento;
	
	// Metodos:
	
	// Construtor
	public Pessoa(String nome, String rg, LocalDate nascimento){
		this.nome = nome;
		this.rg = rg;
		this.dataNascimento = nascimento;
	}

	public String getNome() {
		return this.nome;
	}

	public String getRg() {
		return this.rg;
	}

	public LocalDate getDataNascimento() {
		return this.dataNascimento;
	}
	
	public void imprimirDados() {
		System.out.println("-Nome: " + getNome());
		System.out.println("-RG: " + getRg());
		System.out.println("-Data de nascimento: " + this.getDataNascimento().toString());
		System.out.println();
	}
}
