
import java.util.ArrayList;

public class Animal 
{
	private String genero;
	private String especie;
	private char sexo;
	private String nomePopular;
	private String curiosidade;
	private String origem;
	private ArrayList<Alimento> alimentacaoDiaria;
	private int id;
	private int idade;
	
	public Animal(String genero, String especie, char sexo, String nomePopular, String origem, int id)
	{
            this.alimentacaoDiaria = new ArrayList();
            this.genero = genero;
            this.especie = especie;
            this.sexo = sexo;
            this.nomePopular = nomePopular;
            this.origem = origem;
            this.id = id;
	}

        /**
         * 
         * @return 
         */
	public String getGenero() 
	{
            return genero;
	}
	
        /**
         * 
         * @return 
         */
	public String getEspecie() 
	{
            return especie;
	}
	
        /**
         * 
         * @return 
         */
	public char getSexo()
	{
            return sexo;
	}
	
        /**
         * 
         * @return 
         */
	public String getNomePopular() 
	{
            return nomePopular;
	}
	
        /**
         * 
         * @return 
         */
	public int getId() 
	{
            return id;
	}
	
        /**
         * 
         * @return 
         */
	public int getIdade() 
	{
            return idade;
	}
	
        /**
         * 
         * @return 
         */
	public String getCuriosidade() 
	{
            return curiosidade;
	}
	
        /**
         * 
         * @param curiosidade 
         */
	public void setCuriosidade(String curiosidade)
	{
            this.curiosidade = curiosidade;
	}
	
        /**
         * 
         * @return 
         */
	public String getOrigem() 
	{
            return origem;
	}
	
        /**
         * 
         * @return 
         */
	public ArrayList<Alimento> getAlimentacaoDiaria() 
	{
            return alimentacaoDiaria;
	}
	
        /**
         * 
         * @param alimento
         * @param dia 
         */
	public void setAlimentacaoDiaria(Alimento alimento, int dia)
	{
            alimentacaoDiaria.set(dia, alimento);
	}
	
	public void imprimirDados()
	{
            String saida;
            saida = "- Animal " + id + " -\n";
            saida += "Nome popular: " + nomePopular + "\n";
            saida += "G�nero: " + genero + "\n";
            saida += "Esp�cie: " + especie + "\n";
            saida += "Origem: " + origem + "\n";
            saida += "Curiosidade: " + curiosidade + "\n";
            System.out.println(saida);
	}
}