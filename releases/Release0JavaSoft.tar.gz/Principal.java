
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gabomfim99
 */
public class Principal {

    public static void main(String[] args) {
        Financas financas = new Financas(100000);
        Visitante visitante = new Visitante("Antonio Nunes", "438782652", LocalDate.of(1999, Month.JANUARY, 1), LocalDate.of(2014, Month.JANUARY, 1), Visitante.ASSOCIADO);
        Funcionario funcionario = new Funcionario("Antonio fagundes", "439789952", LocalDate.of(1989, Month.FEBRUARY, 1), Funcionario.TURNO_MANHA, "4532970", 6700, LocalDate.of(2010, Month.JANUARY, 7));
        Animal animal = new Animal("jobarius", "cavalo", 'm', "zebra azul-marinho", "China insular", 35768900);
        Loja loja = new Loja("Quica Gomes Coxinhas", LocalTime.of(8, 0), LocalTime.of(20, 0), 250);
        
        
        financas.pagarSalario(funcionario);
        financas.receberIngresso(visitante);
        financas.receberAluguel(loja);
        
        funcionario.imprimirDados();
        animal.imprimirDados();
        loja.imprimirDados();
        financas.imprimirDados();
    }
}
