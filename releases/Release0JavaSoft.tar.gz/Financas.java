import java.time.LocalDate;

public class Financas {
    public static final double VALOR_INGRESSO = 50.00;
    public static final double VALOR_INGRESSO_MEIA = VALOR_INGRESSO/2;
    public static final double DESCONTO_ASSOCIADO = 10.00;
    private double caixa;

    Financas(double caixa){
        this.setCaixa(caixa);
    }

    public void receberIngresso(Visitante visitante) {

        if(LocalDate.now().getYear()-visitante.getDataNascimento().getYear() <= 18){
            setCaixa(getCaixa() - VALOR_INGRESSO_MEIA);
        }else{
            setCaixa(getCaixa() - VALOR_INGRESSO);
        }
        if(visitante.isAssociado()){
            setCaixa(getCaixa() + DESCONTO_ASSOCIADO);
        }
    }
    
    public void pagarSalario(Funcionario funcionario) {
        setCaixa(getCaixa() - funcionario.getSalario());
    }
        
    public void receberAluguel(Loja loja){
        setCaixa(getCaixa() - loja.getValorAluguel());
    }

    public double getCaixa() {
        return caixa;
    }

    public void setCaixa(double caixa) {
        this.caixa = caixa;
    }

    public void imprimirDados() {
        System.out.println("-Caixa: " + getCaixa());
    }
}
