public class Alimento
{
	private String nome;
	private String localArmazenamento;
	private int temperaturaArmazenamento;
	
	public Alimento(String nome, String localArmazenamento, int temperaturaArmazenamento) 
	{
		this.nome = nome;
		this.localArmazenamento = localArmazenamento;
		this.temperaturaArmazenamento = temperaturaArmazenamento;
	}

	public String getNome() 
	{
		return nome;
	}

	public String getLocalArmazenamento() 
	{
		return localArmazenamento;
	}
	
	public int getTemperaturaArmazenamento() 
	{
		return temperaturaArmazenamento;
	}
}