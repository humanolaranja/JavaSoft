import java.util.ArrayList;

public class Jaula 
{
	private int numMaxAnimais;
	private int numAtualAnimais;
	private int id;
	private ArrayList<Animal> animais = new ArrayList<>();
	private String responsavel;
	
	public Jaula(int numMaxAnimais, int id, String responsavel)
	{
		this.numMaxAnimais = numMaxAnimais;
		this.id = id;
		this.responsavel = responsavel;
	}

	public int getNumMaxAnimais()
	{
		return numMaxAnimais;
	}
	
	public int getNumAtualAnimais()
	{
		return numAtualAnimais;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	public int getId()
	{
		return id;
	}
	
	public String getResponsavel() 
	{
		return responsavel;
	}

	public void setResponsavel(String responsavel) 
	{
		this.responsavel = responsavel;
	}
	
	public ArrayList<Animal> getAnimais()
	{
		return animais;
	}
	
	public void addAnimal(Animal novo)
	{
		if(numAtualAnimais < numMaxAnimais)
		{
			animais.add(novo);
			numAtualAnimais++;
		}
		else
			System.out.println("A jaula j� est� cheia.");
	}
	
	public void removeAnimal(Animal alvo)
	{
		if(animais.contains(alvo))
		{
			animais.remove(alvo);
			numAtualAnimais--;
		}
		else
			System.out.println("O animal desejado n�o est� nessa jaula.");
	}

        @Override
	public String toString()
	{
		String saida;
		saida = "- Jaula " + id + " -\n";
		saida += "Capacidade: " + numAtualAnimais + "/" + numMaxAnimais + "\n";
		saida += "Animais (ID): ";
		for(int i=0; i<animais.size()-1; i++)
			saida += animais.get(i).getId() + ", ";
		saida += animais.get((animais.size()-1)).getId() + "\n";
		
		return saida;
	}
}